pluginid = 'plugin.video.m3utemplate'
host='local'